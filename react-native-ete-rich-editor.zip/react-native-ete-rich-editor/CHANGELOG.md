
## 1.0.6

### Fix Bug
- Fix `selected toolbar` error


## 1.0.5

### Added
- Add `useContainer` props Wrap the editor webview inside a container
- Add `placeholder` props Wrap the editor content placeholder


### Changed
- Upgrade `componentWillReceiveProps` to `getDerivedStateFromProps`
- Upgrade `props` site on hideKeyboardAccessoryView and keyboardDisplayRequiresUserAction end
- Upgrade `Examples` to RN 0.62.0 Webview 9.0.1

### Removed
- Removing experimental `componentWillMount`
